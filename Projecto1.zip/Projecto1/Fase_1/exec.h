#ifndef EXEC_H
#define EXEC_H

#include <iostream>
#include <stdio.h>
using namespace std;


void Instruccion_EXEC(string path)
{

FILE *archivo = fopen(path.c_str(), "r"); // abrir el archivo en modo lectura

     if(archivo != NULL)
     {
        bool descartar = false; // para descartar los comentarios
        string texto = "";
        string texto_comentado = "";
        char c;

          while((c=fgetc(archivo))!=EOF)
          {

             if(c != 10) // Lee todos los caracteres entrantes hasta que encuentre el salto de linea
             {
                 if(c == 35) /* El inicio de un comentario c = # */
                   descartar = true;

                  if(!descartar)
                  {
                     texto += c;

                  } else{ /*concatenar lo comentado para luego solo mostrarlo en la consola*/

                      texto_comentado += c;
                  }

             }
             else
             {
                 if(texto != "") // implica que si leyo una palabra
                 {
                     cout<<texto;
                     if(texto_comentado != "")
                     {
                             cout<<texto_comentado;
                     }
                     cout<<"\n";
                     //Interprete(texto);
                 }
               /*inicializar denuevo las variables */
                            descartar = false; // para descartar los comentarios
                            texto="";
                            texto_comentado="";
             }

          } /*while que termina hasta leer todo el archivo*/

     }
     else{
        cout<<"Exec: Error al abrir el archivo:"<< path <<endl;
     }



}




#endif // EXEC_H
